from flask import Flask, render_template

app = Flask(__name__)


@app.route('/')
def index():
    return render_template("index.html")


@app.route("/dojo")
def dojo():
    return "Dojo!"


@app.route("/say/<string:name>")
def word(name):
    return f"Hi {name}!"


@app.route("/repeat/<int:num>/<string:word>")
def repeat(num, word):
    return word * num


if __name__ == "__main__":
    app.run(debug=True)
